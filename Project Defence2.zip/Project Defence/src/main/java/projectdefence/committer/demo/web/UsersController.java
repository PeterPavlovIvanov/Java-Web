package projectdefence.committer.demo.web;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import projectdefence.committer.demo.models.bindings.UserLoginBindModel;
import projectdefence.committer.demo.models.bindings.UserRegisterBindModel;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.UserServiceModel;
import projectdefence.committer.demo.services.UserService;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Collections;

@Controller
@RequestMapping("/users")
public class UsersController {

    private final UserService userService;
    private final ModelMapper modelMapper;

    public UsersController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/register")
    public ModelAndView getRegister(@Valid
                                    @ModelAttribute("userRegisterBindModel") UserRegisterBindModel userRegisterBindModel,
                                    BindingResult bindingResult, ModelAndView modelAndView) {
        modelAndView.addObject("userRegisterBindModel", userRegisterBindModel);
        modelAndView.setViewName("register");
        return modelAndView;
    }

    @PostMapping("/register")
    public ModelAndView postRegister(@Valid
                                     @ModelAttribute("userRegisterBindModel") UserRegisterBindModel userRegisterBindModel,
                                     BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                     RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors() ||
                !userRegisterBindModel.getPassword().equals(userRegisterBindModel.getRepeatPassword())) {
            redirectAttributes.addFlashAttribute("userRegisterBindModel", userRegisterBindModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userRegBindModel", bindingResult);
            modelAndView.setViewName("redirect:/users/register");
        } else {
            if (!userRegisterBindModel.getRepeatPassword().equals(userRegisterBindModel.getPassword())) {
                redirectAttributes.addFlashAttribute("userRegisterBindModel", userRegisterBindModel);
                redirectAttributes.addFlashAttribute("pNoMatch", true);
                modelAndView.setViewName("redirect:/users/register");
            } else {
                if (this.userService.getByNickname(userRegisterBindModel.getNickname()) != null) {
                    redirectAttributes.addFlashAttribute("userRegisterBindModel", userRegisterBindModel);
                    redirectAttributes.addFlashAttribute("nickTaken", true);
                    modelAndView.setViewName("redirect:/users/register");
                } else if (this.userService.getByEmail(userRegisterBindModel.getEmail()) != null) {
                    redirectAttributes.addFlashAttribute("userRegisterBindModel", userRegisterBindModel);
                    redirectAttributes.addFlashAttribute("emailTaken", true);
                    modelAndView.setViewName("redirect:/users/register");
                } else {

                    UserServiceModel userServiceModel = this.modelMapper.map(userRegisterBindModel, UserServiceModel.class);
                    this.userService.registerUser(userServiceModel);
                    modelAndView.setViewName("redirect:/users/login");
                }
            }
        }
        return modelAndView;
    }

    @GetMapping("/login")
    public String getLogin(Model model) {
        if (model.getAttribute("userLoginBindModel") == null) {
            model.addAttribute("userLoginBindModel", new UserLoginBindModel());
        }
        return "login";
    }

    @PostMapping("/login")
    public ModelAndView postLogin(@Valid
                                  @ModelAttribute("userLoginBindModel") UserLoginBindModel userLoginBindModel,
                                  BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                  RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("userLoginBindModel", userLoginBindModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userLoginBindModel", bindingResult);
            modelAndView.setViewName("redirect:/users/login");
        } else {
            UserServiceModel userServiceModel = this.userService.getByNickname(userLoginBindModel.getNickname());

            if (userServiceModel == null || !userServiceModel.getPassword().equals(userLoginBindModel.getPassword())) {
                redirectAttributes.addFlashAttribute("notFound", true);
                redirectAttributes.addFlashAttribute("userLoginBindModel", userLoginBindModel);
                modelAndView.setViewName("redirect:/users/login");
            } else {
                httpSession.setAttribute("user", this.modelMapper.map(userServiceModel, User.class));
                httpSession.setAttribute("id", userServiceModel.getId());
                modelAndView.setViewName("redirect:/");
            }
        }

        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView getLogout(ModelAndView modelAndView, HttpSession httpSession) {
        httpSession.invalidate();
        modelAndView.setViewName("redirect:/");
        return modelAndView;
    }

    @GetMapping("/profile")
    public ModelAndView getDetails(@RequestParam("id") String id, ModelAndView modelAndView, HttpSession httpSession) {
        User user = this.userService.getById(id);
        Collections.reverse(user.getPosts());
        //reverses the list so the newest posts can be on the top

        User userLogged = (User) httpSession.getAttribute("user");
        if (userLogged.getId().equals(user.getId())) {
            modelAndView.addObject("isOwner", true);
        }
        //Only the owner of the posts can delete them.

        modelAndView.addObject("user", user);
        modelAndView.setViewName("profile");
        return modelAndView;
    }
}
