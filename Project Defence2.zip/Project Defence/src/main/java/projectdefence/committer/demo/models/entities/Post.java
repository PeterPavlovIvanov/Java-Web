package projectdefence.committer.demo.models.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@Table
public class Post extends BaseEntity {
    private String title;
    private String text;
    private User committer;
    private int points;
    List<User> upVoted;
    List<User> downVoted;

    public Post() {
    }

    @Column(nullable = false)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Column(nullable = false)
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @ManyToOne
    public User getCommitter() {
        return committer;
    }

    public void setCommitter(User committer) {
        this.committer = committer;
    }

    @Column
    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @ManyToMany
    public List<User> getUpVoted() {
        return upVoted;
    }

    public void setUpVoted(List<User> upVoted) {
        this.upVoted = upVoted;
    }

    @ManyToMany
    public List<User> getDownVoted() {
        return downVoted;
    }

    public void setDownVoted(List<User> downVoted) {
        this.downVoted = downVoted;
    }
}
