package projectdefence.committer.demo.models.services;

import java.util.List;

public class PostServiceModel extends BaseServiceModel{
    private String title;
    private String text;
    private int likes;
    private int dislikes;
    private UserServiceModel committer;

    public PostServiceModel() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getDislikes() {
        return dislikes;
    }

    public void setDislikes(int dislikes) {
        this.dislikes = dislikes;
    }

    public UserServiceModel getCommitter() {
        return committer;
    }

    public void setCommitter(UserServiceModel committer) {
        this.committer = committer;
    }

}
