package projectdefence.committer.demo.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.services.UserService;
import projectdefence.committer.demo.services.impl.StatsService;

import javax.servlet.http.HttpSession;

@Controller
public class StatsController {

    private StatsService statsService;
    private final UserService userService;

    public StatsController(StatsService statsService, UserService userService) {
        this.statsService = statsService;
        this.userService = userService;
    }

    @GetMapping("/stats")
    public String stats(Model model, HttpSession httpSession) {

        model.addAttribute("requestCount", statsService.getRequestCount());
        model.addAttribute("startedOn", statsService.getStartedOn());

        User u = (User) httpSession.getAttribute("user");
        User user = this.userService.getById(u.getId());
        if (user.getRole().getRoleName().toString().equals("ADMIN")) {
            //model.addAttribute("isADMIN", true);
            return "stats";
        } else {
            return "error";
        }

    }

}
