package projectdefence.committer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableWebSecurity
public class CommitterApplication {

    public static void main(String[] args) {
        SpringApplication.run(CommitterApplication.class, args);
    }

}
