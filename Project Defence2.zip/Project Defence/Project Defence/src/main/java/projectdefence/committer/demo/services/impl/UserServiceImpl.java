package projectdefence.committer.demo.services.impl;

import org.modelmapper.ModelMapper;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.models.bindings.UserChangeRoleBindModel;
import projectdefence.committer.demo.models.entities.Role;
import projectdefence.committer.demo.models.entities.RoleName;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.UserServiceModel;
import projectdefence.committer.demo.repositories.UserRepository;
import projectdefence.committer.demo.services.RoleService;
import projectdefence.committer.demo.services.UserService;

import java.util.Optional;
import java.util.stream.Collectors;

//implements UserDetailsService
@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final RoleService roleService;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, RoleService roleService) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.roleService = roleService;
    }

    @Override
    public void registerUser(UserServiceModel userServiceModel) {

        if (this.userRepository.count() == 0) {
            userServiceModel.setRoleServiceModel(this.roleService.getByRoleName(RoleName.ADMIN));
        } else {
            userServiceModel.setRoleServiceModel(this.roleService.getByRoleName(RoleName.USER));
        }
        User user = this.modelMapper.map(userServiceModel, User.class);
        this.userRepository.saveAndFlush(user);
    }

    @Override
    public UserServiceModel getByEmail(String email) {
        return this.userRepository
                .findByEmail(email)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }

    @Override
    public UserServiceModel getByNickname(String nickname) {
        return this.userRepository
                .findByNickname(nickname)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }

    @Override
    public User getById(String id) {
        return this.userRepository
                .findById(id)
                .orElse(null);
    }

    @Override
    public void changeRole(UserChangeRoleBindModel userChangeRoleBindModel) {
        User user = this.userRepository
                .findByNickname(userChangeRoleBindModel.getNickname())
                .orElse(null);

        user.setRole(this.modelMapper.map(this.roleService.getByRoleName(userChangeRoleBindModel.getRoleName()), Role.class));
        this.userRepository.save(user);
    }

//    @Override
//    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
//        Optional<User> userEntityOpt = userRepository.findByNickname(s);
//        return userEntityOpt.
//                map(this::map).
//                orElseThrow(() -> new UsernameNotFoundException("User " + s + " not found!"));
//    }
//
//    private UserDetails map(User userEntity) {
//        return new org.springframework.security.core.userdetails.User(
//                userEntity.getNickname(),
//                userEntity.getPassword(),
//                userEntity.authorities()
//                        .stream()
//                        .map(this::map)
//                        .collect(Collectors.toList()));
//    }
//
//    private GrantedAuthority map(Role role) {
//        return new SimpleGrantedAuthority(role.getRoleName().toString());
//    }

}
