package projectdefence.committer.demo.models.entities;

public enum RoleName {
    ADMIN, USER
}
