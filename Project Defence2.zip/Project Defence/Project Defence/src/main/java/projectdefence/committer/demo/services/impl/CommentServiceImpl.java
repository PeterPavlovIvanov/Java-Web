package projectdefence.committer.demo.services.impl;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.services.CommentService;

@Service
public class CommentServiceImpl implements CommentService {
}
