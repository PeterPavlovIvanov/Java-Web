package projectdefence.committer.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import projectdefence.committer.demo.models.entities.Follower;

import java.util.Set;

@Repository
public interface FollowerRepository extends JpaRepository<Follower, String> {
    Follower findByFollowed_Id(String followedId);
}
