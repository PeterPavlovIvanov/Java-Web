package projectdefence.committer.demo.services;

import projectdefence.committer.demo.models.entities.Follower;
import projectdefence.committer.demo.models.entities.User;

import java.util.Set;

public interface FollowerService {
    void follow(String followerId, String followedId);
    void unfollow(String followerId, String followedId);
    Set<User> getFollowers(User user);
}
