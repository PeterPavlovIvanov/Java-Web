package projectdefence.committer.demo.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.UserServiceModel;
import projectdefence.committer.demo.services.PostService;
import projectdefence.committer.demo.services.RoleService;
import projectdefence.committer.demo.services.UserService;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {
    private final RoleService roleService;
    private final PostService postService;

    public HomeController(RoleService roleService, PostService postService) {
        this.roleService = roleService;
        this.postService = postService;
    }

    @GetMapping("/")
    public ModelAndView getHome(HttpSession httpSession, ModelAndView modelAndView) {
        this.roleService.init();

        if (httpSession.getAttribute("user") == null) {
            modelAndView.setViewName("index");
        } else {
//            User u = (User) httpSession.getAttribute("user");
//            if (u.getRole().getRoleName().toString().equals("ADMIN")) {
//                modelAndView.addObject("isAdmin", true);
//            }
            modelAndView.setViewName("home");
            modelAndView.addObject("allPosts", this.postService.getAll());
            modelAndView.addObject("user", httpSession.getAttribute("user"));
            modelAndView.addObject("userId", httpSession.getAttribute("id"));
        }
        return modelAndView;
    }

}
