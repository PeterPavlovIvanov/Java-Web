package projectdefence.committer.demo.services.impl;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.models.entities.Follower;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.repositories.FollowerRepository;
import projectdefence.committer.demo.repositories.UserRepository;
import projectdefence.committer.demo.services.FollowerService;

import java.util.HashSet;
import java.util.Set;

@Service
public class FollowerServiceImpl implements FollowerService {
    private final FollowerRepository followerRepository;
    private final UserRepository userRepository;

    public FollowerServiceImpl(FollowerRepository followerRepository, UserRepository userRepository) {
        this.followerRepository = followerRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void follow(String followerId, String followedId) {
        if (this.followerRepository.findByFollowed_Id(followedId) == null) {
            Follower follower = new Follower();
            follower.setFollowed(this.userRepository.findById(followedId).orElse(null));

            Set<User> followers = new HashSet<>();
            followers.add(this.userRepository.findById(followerId).orElse(null));
            follower.setFollowers(followers);

            this.followerRepository.saveAndFlush(follower);
        } else {
           Follower follower = this.followerRepository.findByFollowed_Id(followedId);

           follower.getFollowers().add(this.userRepository.findById(followerId).orElse(null));

           this.followerRepository.saveAndFlush(follower);
        }
    }

    @Override
    public void unfollow(String followerId, String followedId) {
        Follower follower = this.followerRepository.findByFollowed_Id(followedId);

        follower.getFollowers().remove(this.userRepository.findById(followedId));

        this.followerRepository.saveAndFlush(follower);
    }

    @Override
    public Set<User> getFollowers(User user) {
        Follower byFollowed_id = this.followerRepository.findByFollowed_Id(user.getId());
        return byFollowed_id.getFollowers();
    }
}
