package projectdefence.committer.demo.models.entities;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table
public class Follower extends BaseEntity{
    private User followed;
    private Set<User> followers;

    public Follower() {
    }

    @OneToOne
    public User getFollowed() {
        return followed;
    }

    public void setFollowed(User followed) {
        this.followed = followed;
    }

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(cascade = CascadeType.ALL)
    public Set<User> getFollowers() {
        return followers;
    }

    public void setFollowers(Set<User> friends) {
        this.followers = friends;
    }
}
