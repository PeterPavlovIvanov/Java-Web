package softuni.one.service;

import softuni.one.model.service.ExerciseServiceModel;

public interface ExerciseService {
    void addEx(ExerciseServiceModel exerciseServiceModel);
}
