package softuni.one.service;

import softuni.one.model.service.UserServiceModel;

import java.util.List;

public interface UserService {
    UserServiceModel registerUser(UserServiceModel userServiceModel);

    UserServiceModel findByUserName(String username);

    List<String> findAllUsernames();

    void addRoleToUser(String username, String role);
}
