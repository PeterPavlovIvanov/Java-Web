package softuni.one.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(HttpSession httpSession){
        System.out.println();
        return httpSession.getAttribute("user") == null ? "index" : "home";
    }

}
