package softuni.one.web;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.one.model.binding.ExerciseAddBindingModel;
import softuni.one.model.service.ExerciseServiceModel;
import softuni.one.service.ExerciseService;
import softuni.one.service.UserService;
import javax.validation.Valid;


@Controller
@RequestMapping("/exercises")
public class ExerciseController {
    private final ModelMapper modelMapper;
    private final ExerciseService exerciseService;

    @Autowired
    public ExerciseController( ModelMapper modelMapper, ExerciseService exerciseService) {
        this.modelMapper = modelMapper;
        this.exerciseService = exerciseService;
    }

    @GetMapping("/add")
    public ModelAndView add(@Valid @ModelAttribute("exerciseAddBindingModel") ExerciseAddBindingModel exerciseAddBindingModel,
                            ModelAndView modelAndView) {
        modelAndView.addObject("exerciseAddBindingModel",exerciseAddBindingModel);
        modelAndView.setViewName("exercise-add");
        return modelAndView;
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(@Valid @ModelAttribute("exerciseAddBindingModel") ExerciseAddBindingModel exerciseAddBindingModel,
                             BindingResult bindingResult, ModelAndView modelAndView, RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("exerciseAddBindingModel", exerciseAddBindingModel);
            modelAndView.setViewName("redirect:/exercises/add");
        } else {
            this.exerciseService.addEx(this.modelMapper.map(exerciseAddBindingModel, ExerciseServiceModel.class));
            modelAndView.setViewName("redirect:/");
        }

        return modelAndView;
    }
}
