package softuni.one.web;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.one.model.binding.UserAddBindingModel;
import softuni.one.model.binding.UserLoginBindingModel;
import softuni.one.model.entity.User;
import softuni.one.model.service.UserServiceModel;
import softuni.one.service.UserService;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class UserController {
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/login")
    public ModelAndView login(@Valid
                            @ModelAttribute("userLoginBindingModel") UserLoginBindingModel userLoginBindingModel,
                        BindingResult bindingResult, ModelAndView modelAndView) {

        modelAndView.addObject("userLoginBindingModel",userLoginBindingModel);
        modelAndView.setViewName("login");
        return modelAndView;
    }

    @GetMapping("/register")
    public ModelAndView register(@Valid
                               @ModelAttribute("userAddBindingModel") UserAddBindingModel userAddBindingModel,
                           BindingResult bindingResult, ModelAndView modelAndView) {

        modelAndView.addObject("userAddBindingModel",userAddBindingModel);
        modelAndView.setViewName("register");
        return modelAndView;
    }

    @PostMapping("/login")
    private ModelAndView loginPost(@Valid
                                       @ModelAttribute("userLoginBindingModel") UserLoginBindingModel userLoginBindingModel,
                                   BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                   RedirectAttributes redirectAttributes){

        if(bindingResult.hasErrors()){
            redirectAttributes.addFlashAttribute("userLoginBindingModel",userLoginBindingModel);
            modelAndView.setViewName("redirect:/users/login");
        } else {
            UserServiceModel user = this.userService
                    .findByUserName(userLoginBindingModel.getUsername());

            if(user == null || !user.getPassword().equals(userLoginBindingModel.getPassword())){
                redirectAttributes.addFlashAttribute("notFound", true);
                redirectAttributes.addFlashAttribute("userLoginBindingModel",userLoginBindingModel);
                modelAndView.setViewName("redirect:/users/login");
            }else{
                httpSession.setAttribute("user",user);
                httpSession.setAttribute("id",user.getId());
                httpSession.setAttribute("role",user.getRole().getName());
                modelAndView.setViewName("redirect:/");
            }
        }
        return modelAndView;
    }

    @PostMapping("/register")
    public ModelAndView registerPost(@Valid
                                     @ModelAttribute("userAddBindingModel") UserAddBindingModel userAddBindingModel,
                                     BindingResult bindingResult, ModelAndView modelAndView, RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("userAddBindingModel",userAddBindingModel);
            modelAndView.setViewName("redirect:/users/register");
        } else {
            UserServiceModel userToRegister = this.modelMapper.map(userAddBindingModel, UserServiceModel.class);
            UserServiceModel userServiceModel = this.userService.registerUser(userToRegister);
            modelAndView.setViewName("redirect:/users/login");
        }

        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView logout(ModelAndView modelAndView, RedirectAttributes redirectAttributes,
                               HttpSession httpSession){

        httpSession.setAttribute("user",null);
        modelAndView.setViewName("redirect:/");

        return modelAndView;
    }
}
