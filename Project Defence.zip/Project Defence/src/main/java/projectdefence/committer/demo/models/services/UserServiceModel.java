package projectdefence.committer.demo.models.services;

import projectdefence.committer.demo.models.entities.Role;

public class UserServiceModel extends BaseServiceModel{

    private String nickname;
    private String password;
    private String email;
    private Role role;

    public UserServiceModel() {
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
