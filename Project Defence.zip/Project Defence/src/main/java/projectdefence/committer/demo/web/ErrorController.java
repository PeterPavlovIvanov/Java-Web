package projectdefence.committer.demo.web;

import org.hibernate.TransactionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.persistence.PersistenceException;

@ControllerAdvice
public class ErrorController {

    @ExceptionHandler({TransactionException.class, PersistenceException.class})
    public ModelAndView handleDatabaseErrors() {
        ModelAndView modelAndView = new ModelAndView("error");
        modelAndView.addObject("message", "we got it.");

        return modelAndView;
    }
}
