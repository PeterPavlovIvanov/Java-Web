package projectdefence.committer.demo.services;

public interface RoleService {
}
