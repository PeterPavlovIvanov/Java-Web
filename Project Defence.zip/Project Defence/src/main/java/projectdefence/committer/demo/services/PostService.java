package projectdefence.committer.demo.services;

import projectdefence.committer.demo.models.bindings.PostAddBindModel;

public interface PostService {

    void addACommit(PostAddBindModel postAddBindModel, String id);
}
