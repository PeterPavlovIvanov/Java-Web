package projectdefence.committer.demo.services;

import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.UserServiceModel;

public interface UserService {
    void registerUser(UserServiceModel userServiceModel);
    UserServiceModel getByEmail(String email);
    UserServiceModel getByNickname(String nickname);
    User getById(String id);
}
