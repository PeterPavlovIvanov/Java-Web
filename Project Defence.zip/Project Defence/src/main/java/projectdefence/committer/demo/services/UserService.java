package projectdefence.committer.demo.services;

import projectdefence.committer.demo.models.services.UserServiceModel;

public interface UserService {
    void registerUser(UserServiceModel userServiceModel);
    UserServiceModel getByNickname(String nickname);
}
