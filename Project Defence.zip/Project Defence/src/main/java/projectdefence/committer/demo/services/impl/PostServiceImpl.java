package projectdefence.committer.demo.services.impl;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.services.PostService;

@Service
public class PostServiceImpl implements PostService {
}
