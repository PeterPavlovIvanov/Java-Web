package projectdefence.committer.demo.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import projectdefence.committer.demo.models.entities.Role;
import projectdefence.committer.demo.models.entities.RoleName;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.RoleServiceModel;
import projectdefence.committer.demo.models.services.UserServiceModel;
import projectdefence.committer.demo.repositories.UserRepository;
import projectdefence.committer.demo.services.RoleService;
import projectdefence.committer.demo.services.UserService;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final RoleService roleService;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, RoleService roleService) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.roleService = roleService;
    }

    @Override
    public void registerUser(UserServiceModel userServiceModel) {

        if (this.userRepository.count() == 0) {
            userServiceModel.setRoleServiceModel(this.roleService.getByRoleName(RoleName.ADMIN));
        } else {
            userServiceModel.setRoleServiceModel(this.roleService.getByRoleName(RoleName.MEMBER));
        }
        User user = this.modelMapper.map(userServiceModel, User.class);
        this.userRepository.saveAndFlush(user);
    }

    @Override
    public UserServiceModel getByEmail(String email) {
        return this.userRepository
                .findByEmail(email)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }

    @Override
    public UserServiceModel getByNickname(String nickname) {
        return this.userRepository
                .findByNickname(nickname)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }

    @Override
    public User getById(String id) {
        return this.userRepository
                .findById(id)
                .orElse(null);
    }
}
