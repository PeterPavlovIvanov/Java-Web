package projectdefence.committer.demo.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import projectdefence.committer.demo.models.entities.Role;
import projectdefence.committer.demo.models.entities.User;
import projectdefence.committer.demo.models.services.UserServiceModel;
import projectdefence.committer.demo.repositories.UserRepository;
import projectdefence.committer.demo.services.UserService;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void registerUser(UserServiceModel userServiceModel) {
        Role role = new Role();
        role.setName(this.userRepository.count() == 0 ? "ADMIN" : "MEMBER");
        userServiceModel.setRole(role);
        User user = this.modelMapper.map(userServiceModel, User.class);
        this.userRepository.saveAndFlush(user);
    }

    @Override
    public UserServiceModel getByNickname(String nickname) {
        return this.userRepository
                .findByNickname(nickname)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }
}
