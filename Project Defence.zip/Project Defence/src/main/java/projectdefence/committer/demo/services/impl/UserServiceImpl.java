package projectdefence.committer.demo.services.impl;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.services.UserService;

@Service
public class UserServiceImpl implements UserService {
}
