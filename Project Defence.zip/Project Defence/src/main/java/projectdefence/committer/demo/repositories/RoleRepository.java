package projectdefence.committer.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import projectdefence.committer.demo.models.entities.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, String> {
}
