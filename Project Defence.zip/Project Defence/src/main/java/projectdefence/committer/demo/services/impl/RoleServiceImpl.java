package projectdefence.committer.demo.services.impl;

import org.springframework.stereotype.Service;
import projectdefence.committer.demo.services.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
}
