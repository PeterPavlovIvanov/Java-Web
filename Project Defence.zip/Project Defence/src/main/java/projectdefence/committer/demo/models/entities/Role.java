package projectdefence.committer.demo.models.entities;

import javax.persistence.*;

@Entity
@Table
public class Role extends BaseEntity{
    private RoleName roleName;

    public Role() {
    }

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    public RoleName getRoleName() {
        return roleName;
    }

    public void setRoleName(RoleName roleName) {
        this.roleName = roleName;
    }
}
