package examp.prep.models.bindings;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;

public class UserRegisterBindingModel {
    private String username;
    private String password;
    private String email;
    private double budget;
    private String confirmPassword;

    public UserRegisterBindingModel() {
    }

    public UserRegisterBindingModel(String username, String password, String email, double budget, String confirmPassword) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.budget = budget;
        this.confirmPassword = confirmPassword;
    }

    @Length(min = 3, message = "Username must be more than two characters.")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Length(min = 3, message = "Password must be more than two characters.")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Email(message = "Enter valid email address.")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Min(value = 0,message = "Budget must be more or equal to zero.")
    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    @Length(min = 3, message = "Password must be more than two characters.")
    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
}
