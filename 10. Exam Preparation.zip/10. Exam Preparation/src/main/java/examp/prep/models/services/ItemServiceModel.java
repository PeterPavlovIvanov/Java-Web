package examp.prep.models.services;

import examp.prep.models.entities.CategoryName;

public class ItemServiceModel extends BaseServiceModel{
    private String name;
    private String description;
    private double price;
    private CategoryName categoryName;
    private String gender;

    public ItemServiceModel() {
    }

    public ItemServiceModel(String name, String description, double price, CategoryName categoryName, String gender) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.categoryName = categoryName;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public CategoryName getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(CategoryName categoryName) {
        this.categoryName = categoryName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
