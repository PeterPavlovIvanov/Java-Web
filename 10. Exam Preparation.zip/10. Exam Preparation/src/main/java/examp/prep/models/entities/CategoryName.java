package examp.prep.models.entities;

public enum CategoryName {
    Shirt, Denim, Shorts, Jacket
}
