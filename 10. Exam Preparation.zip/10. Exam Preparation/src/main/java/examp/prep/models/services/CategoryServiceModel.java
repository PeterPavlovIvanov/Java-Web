package examp.prep.models.services;

import examp.prep.models.entities.CategoryName;

public class CategoryServiceModel extends BaseServiceModel{
    private CategoryName categoryName;
    private String description;

    public CategoryServiceModel() {
    }

    public CategoryServiceModel(CategoryName categoryName, String description) {
        this.categoryName = categoryName;
        this.description = description;
    }

    public CategoryName getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(CategoryName categoryName) {
        this.categoryName = categoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
