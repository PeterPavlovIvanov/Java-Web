package examp.prep.models.entities;

import javax.persistence.*;

@Entity
@Table
public class Category extends BaseEntity{
    private CategoryName categoryName;
    private String description;

    public Category() {
    }

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    public CategoryName getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(CategoryName categoryName) {
        this.categoryName = categoryName;
    }

    @Column(nullable = false)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}