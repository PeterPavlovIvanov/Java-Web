package examp.prep.models.bindings;

import examp.prep.models.entities.CategoryName;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.Min;


public class ItemAddBindingModel {
    private String name;
    private String description;
    private double price;
    private CategoryName categoryName;
    private String gender;

    public ItemAddBindingModel() {
    }

    @Length(min = 3, message = "Name must be more than two characters.")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Length(min = 3, message = "Description must be more than three characters.")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Min(value = 0, message = "Price must be positive number.")
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public CategoryName getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(CategoryName categoryName) {
        this.categoryName = categoryName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
