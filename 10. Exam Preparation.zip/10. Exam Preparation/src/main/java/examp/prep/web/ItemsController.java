package examp.prep.web;

import examp.prep.models.bindings.ItemAddBindingModel;
import examp.prep.models.entities.Category;
import examp.prep.models.services.ItemServiceModel;
import examp.prep.services.CategoryService;
import examp.prep.services.ItemService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/items")
public class ItemsController {
    private final ModelMapper modelMapper;
    private final ItemService itemService;
    private final CategoryService categoryService;

    public ItemsController(ModelMapper modelMapper, ItemService itemService, CategoryService categoryService) {
        this.modelMapper = modelMapper;
        this.itemService = itemService;
        this.categoryService = categoryService;
    }

    @GetMapping("/add")
    public String getAddItem(Model model) {
        if (!model.containsAttribute("itemAddBindingModel")) {
            model.addAttribute("itemAddBindingModel", new ItemAddBindingModel());
        }
        return "add-item";
    }

    @PostMapping("/add")
    public ModelAndView postAddItem(@Valid
                                    @ModelAttribute("itemAddBindingModel") ItemAddBindingModel itemAddBindingModel,
                                    BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                    RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("itemAddBindingModel", itemAddBindingModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.itemAddBindingModel", bindingResult);
            modelAndView.setViewName("redirect:/items/add");
        } else {
            this.itemService.addItem(this.modelMapper.map(itemAddBindingModel, ItemServiceModel.class));
            modelAndView.setViewName("redirect:/");
        }

        return modelAndView;
    }

    @GetMapping("/details")
    public ModelAndView getDetails(@RequestParam("id") long id, ModelAndView modelAndView) {
        modelAndView.addObject("item", this.itemService.findById(id));
        modelAndView.setViewName("details-item");
        return modelAndView;
    }

    @GetMapping("/delete/{id}")
    public ModelAndView getDelete(@PathVariable(name = "id") long id, ModelAndView modelAndView) {
        this.itemService.delete(id);
        modelAndView.setViewName("redirect:/");
        return modelAndView;
    }
}
