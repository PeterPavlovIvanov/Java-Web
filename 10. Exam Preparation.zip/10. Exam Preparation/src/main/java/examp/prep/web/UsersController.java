package examp.prep.web;

import examp.prep.models.bindings.UserLoginBindingModel;
import examp.prep.models.bindings.UserRegisterBindingModel;
import examp.prep.models.services.UserServiceModel;
import examp.prep.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class UsersController {
    private final ModelMapper modelMapper;
    private final UserService userService;

    public UsersController(ModelMapper modelMapper, UserService userService) {
        this.modelMapper = modelMapper;
        this.userService = userService;
    }

    @GetMapping("/login")
    public String getLogin(Model model) {
        if (!model.containsAttribute("userLoginBindingModel")) {
            model.addAttribute("userLoginBindingModel", new UserLoginBindingModel());
        }
        return "login";
    }

    @PostMapping("/login")
    public ModelAndView postLogin(@Valid
                                  @ModelAttribute("userLoginBindingModel") UserLoginBindingModel userLoginBindingModel,
                                  BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                  RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("userLoginBindingModel", userLoginBindingModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userLoginBindingModel", bindingResult);
            modelAndView.setViewName("redirect:/users/login");
        } else {
            UserServiceModel userServiceModel = this.userService
                    .findByUsername(userLoginBindingModel.getUsername());

            if (userServiceModel == null || !userServiceModel.getPassword().equals(userLoginBindingModel.getPassword())) {
                redirectAttributes.addFlashAttribute("notFound", true);
                redirectAttributes.addFlashAttribute("userLoginBindingModel", userLoginBindingModel);
                modelAndView.setViewName("redirect:/users/login");
            } else {
                httpSession.setAttribute("user", userServiceModel);
                httpSession.setAttribute("id", userServiceModel.getId());
                modelAndView.setViewName("redirect:/");
            }
        }

        return modelAndView;
    }

    @GetMapping("/register")
    public ModelAndView getRegister(@Valid
                                    @ModelAttribute("userRegisterBindingModel") UserRegisterBindingModel userRegisterBindingModel,
                                    BindingResult bindingResult, ModelAndView modelAndView) {
        modelAndView.addObject("userRegisterBindingModel", userRegisterBindingModel);
        modelAndView.setViewName("register");
        return modelAndView;
    }

    @PostMapping("/register")
    public ModelAndView postRegister(@Valid
                                     @ModelAttribute("userRegisterBindingModel") UserRegisterBindingModel userRegisterBindingModel,
                                     BindingResult bindingResult, ModelAndView modelAndView, HttpSession httpSession,
                                     RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors() ||
                !userRegisterBindingModel.getPassword().equals(userRegisterBindingModel.getConfirmPassword())) {
            redirectAttributes.addFlashAttribute("userRegisterBindingModel", userRegisterBindingModel);
            //redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userRegisterBindingModel", bindingResult);
            modelAndView.setViewName("redirect:/users/register");
        } else {
            UserServiceModel userServiceModel = this.modelMapper.map(userRegisterBindingModel, UserServiceModel.class);
//            if(!userServiceModel.getPassword().equals(userRegisterBindingModel.getPassword())){
//                redirectAttributes.addFlashAttribute("notFound", true);
//                modelAndView.setViewName("redirect:/users/register");
//                return modelAndView;
//            }
            UserServiceModel toReg = this.userService.registerUser(userServiceModel);
            modelAndView.setViewName("redirect:/users/login");
        }
        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView modelAndView(@Valid
                                     @ModelAttribute("userRegisterBindingModel") UserRegisterBindingModel userRegisterBindingModel,
                                     ModelAndView modelAndView, HttpSession httpSession) {
        //httpSession.setAttribute("user", null); i used it but the lector said the next line is the real logout
        httpSession.invalidate();
        modelAndView.setViewName("redirect:/");
        return modelAndView;
    }

}
