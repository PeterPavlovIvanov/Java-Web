package examp.prep.web;

import examp.prep.models.bindings.ItemAddBindingModel;
import examp.prep.models.entities.Item;
import examp.prep.services.CategoryService;
import examp.prep.services.ItemService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;

@Controller
public class HomeController {
    private final ItemService itemService;
    private final CategoryService categoryService;

    public HomeController(ItemService itemService, CategoryService categoryService) {
        this.itemService = itemService;
        this.categoryService = categoryService;
    }

    @GetMapping("/")
    public ModelAndView getHome(ModelAndView modelAndView, HttpSession httpSession) {
        if(this.categoryService.isEmpty()){
            this.categoryService.init();
        }
        if(httpSession.getAttribute("user") != null){
            modelAndView.addObject("allItems", this.itemService.getAllItems());

            modelAndView.setViewName("home");
        }else{
            modelAndView.setViewName("index");
        }
        return modelAndView;
    }
}
