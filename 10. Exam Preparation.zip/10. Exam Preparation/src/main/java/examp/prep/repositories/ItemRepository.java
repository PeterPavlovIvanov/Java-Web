package examp.prep.repositories;

import examp.prep.models.entities.Item;
import examp.prep.models.views.ItemViewModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
    @Query(value = "SELECT * FROM Item ", nativeQuery = true)
    List<Item> getAll();
    Optional<Item> getById(long id);
}

