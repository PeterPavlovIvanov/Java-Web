package examp.prep.services;

import examp.prep.models.entities.Category;
import examp.prep.models.entities.CategoryName;

import java.util.List;

public interface CategoryService {
    List<Category> init();

    Category findByCategoryName(CategoryName categoryName);

    boolean isEmpty();
}
