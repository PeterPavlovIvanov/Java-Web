package examp.prep.services.impl;

import examp.prep.models.entities.Item;
import examp.prep.models.services.ItemServiceModel;
import examp.prep.models.views.ItemViewModel;
import examp.prep.repositories.ItemRepository;
import examp.prep.services.CategoryService;
import examp.prep.services.ItemService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ItemServiceImpl implements ItemService {
    private final ItemRepository itemRepository;
    private final CategoryService categoryService;
    private final ModelMapper modelMapper;

    public ItemServiceImpl(ItemRepository itemRepository, CategoryService categoryService, ModelMapper modelMapper) {
        this.itemRepository = itemRepository;
        this.categoryService = categoryService;
        this.modelMapper = modelMapper;
    }

    @Override
    public void addItem(ItemServiceModel itemServiceModel) {
        Item item = this.modelMapper.map(itemServiceModel, Item.class);
        item.setCategory(this.categoryService.findByCategoryName(itemServiceModel.getCategoryName()));
        this.itemRepository.saveAndFlush(item);
    }

    @Override
    public List<ItemViewModel> getAllItems() {
        return this.itemRepository
                .getAll()
                .stream()
                .map(i -> {
                    ItemViewModel itemViewModel = this.modelMapper.map(i, ItemViewModel.class);
                    itemViewModel.setImgUrl(String.format("/img/%s-%s.jpg",
                            i.getGender(),
                            i.getCategory().getCategoryName().name())
                    );
                    return itemViewModel;
                }).collect(Collectors.toList());
    }

    @Override
    public ItemViewModel findById(long id) {
        return this.itemRepository
                .findById(id)
                .map(i -> {
                    ItemViewModel itemViewModel = this.modelMapper.map(i, ItemViewModel.class);
                    itemViewModel.setImgUrl(String.format("/img/%s-%s.jpg",
                            i.getGender(), i.getCategory().getCategoryName().name()));
                    return itemViewModel;
                }).orElse(null);
    }

    @Override
    public void delete(long id) {
        this.itemRepository.delete(this.itemRepository.getById(id).orElse(null));// v repo ima i vgraden deleteById TODO CHECK
    }

}
