package examp.prep.services.impl;

import examp.prep.models.entities.User;
import examp.prep.models.services.UserServiceModel;
import examp.prep.repositories.UserRepository;
import examp.prep.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public UserServiceModel registerUser(UserServiceModel userServiceModel) {
        User u = this.modelMapper.map(userServiceModel, User.class);
        this.userRepository.saveAndFlush(u);
        return userServiceModel;
    }

    @Override
    public UserServiceModel findByUsername(String username) {
        return this.userRepository
                .findByUsername(username)
                .map(u -> this.modelMapper.map(u, UserServiceModel.class))
                .orElse(null);
    }
}
