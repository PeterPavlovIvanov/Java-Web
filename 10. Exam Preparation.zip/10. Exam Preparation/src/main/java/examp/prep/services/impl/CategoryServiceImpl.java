package examp.prep.services.impl;

import examp.prep.models.entities.Category;
import examp.prep.models.entities.CategoryName;
import examp.prep.models.services.CategoryServiceModel;
import examp.prep.repositories.CategoryRepository;
import examp.prep.services.CategoryService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;
    private final ModelMapper modelMapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<Category> init() {
        List<Category> categories = new ArrayList<>();
        if(categoryRepository.count() == 0){
            Category category1 = new Category();
            Category category2 = new Category();
            Category category3 = new Category();
            Category category4 = new Category();
            category1.setCategoryName(CategoryName.Shirt);
            category1.setDescription("This is shirt clothing.");

            category2.setCategoryName(CategoryName.Denim);
            category2.setDescription("This is denim clothing.");

            category3.setCategoryName(CategoryName.Shorts);
            category3.setDescription("This is shorts clothing.");

            category4.setCategoryName(CategoryName.Jacket);
            category4.setDescription("This is jacket clothing.");
            this.categoryRepository.saveAndFlush(category1);
            this.categoryRepository.saveAndFlush(category2);
            this.categoryRepository.saveAndFlush(category3);
            this.categoryRepository.saveAndFlush(category4);
        }
        categories.add(this.categoryRepository.getByCategoryName(CategoryName.Shirt));
        categories.add(this.categoryRepository.getByCategoryName(CategoryName.Denim));
        categories.add(this.categoryRepository.getByCategoryName(CategoryName.Shorts));
        categories.add(this.categoryRepository.getByCategoryName(CategoryName.Jacket));
        return categories;
    }

    @Override
    public Category findByCategoryName(CategoryName categoryName) {
        return this.categoryRepository.findByCategoryName(categoryName).orElse(null);

    }

    @Override
    public boolean isEmpty() {
        return this.categoryRepository.count() == 0;
    }
}
