package examp.prep.services;

import examp.prep.models.entities.Item;
import examp.prep.models.services.ItemServiceModel;
import examp.prep.models.views.ItemViewModel;

import java.util.List;

public interface ItemService {
    void addItem(ItemServiceModel itemServiceModel);

    List<ItemViewModel> getAllItems();

    ItemViewModel findById(long id);

    void delete(long id);

}
