package examp.prep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrepApplicationTests {

    @Test
    void contextLoads() {
    }

}
